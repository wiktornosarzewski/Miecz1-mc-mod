7.11.2022
Mod by Wiktor Nosarzewski nosatech
Name = Miecz1
Minecraft version: forge-1.19.2
Required: Minecraft Forge mod loader
Forge 1.19.2
---
File v1.2

Thank you for choosing our product!
~ nosatech